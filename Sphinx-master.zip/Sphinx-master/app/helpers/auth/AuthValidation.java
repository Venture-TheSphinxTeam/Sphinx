package helpers.auth;

public interface AuthValidation {
	
	String validateUser(String user, String password);

}
