package models;

public class ChangeIcon {
	public String userImageURL;
}
