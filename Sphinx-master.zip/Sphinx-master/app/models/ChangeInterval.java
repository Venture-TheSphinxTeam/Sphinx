package models;

public class ChangeInterval {
	
	public Integer interval;

}
